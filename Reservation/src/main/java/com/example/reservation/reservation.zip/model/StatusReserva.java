package com.example.reservation.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public enum StatusReserva {
    ATIVA,
    CANCELADA
}
